﻿namespace Adicionar_Funcionário
{
    partial class frmCadastroCargosDadosBancarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txbIDCargo = new System.Windows.Forms.TextBox();
            this.lblIDCargo = new System.Windows.Forms.Label();
            this.txbDataAdmissao = new System.Windows.Forms.TextBox();
            this.lblDataAdmissao = new System.Windows.Forms.Label();
            this.txbSalarioHora = new System.Windows.Forms.TextBox();
            this.lblSalarioHora = new System.Windows.Forms.Label();
            this.txbOperacao = new System.Windows.Forms.TextBox();
            this.lblOperacao = new System.Windows.Forms.Label();
            this.txbCargo = new System.Windows.Forms.TextBox();
            this.lblCargo = new System.Windows.Forms.Label();
            this.txbDepartamento = new System.Windows.Forms.TextBox();
            this.lblDepartamento = new System.Windows.Forms.Label();
            this.txbJornadaTrabalho = new System.Windows.Forms.TextBox();
            this.lblJornadaTrabalho = new System.Windows.Forms.Label();
            this.txbSalarioMensal = new System.Windows.Forms.TextBox();
            this.lblSalarioMensal = new System.Windows.Forms.Label();
            this.txbAgencia = new System.Windows.Forms.TextBox();
            this.lblAgencia = new System.Windows.Forms.Label();
            this.txbConta = new System.Windows.Forms.TextBox();
            this.lblConta = new System.Windows.Forms.Label();
            this.txbBanco = new System.Windows.Forms.TextBox();
            this.lblBanco = new System.Windows.Forms.Label();
            this.btnProximo = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txbIDCargo
            // 
            this.txbIDCargo.Location = new System.Drawing.Point(89, 66);
            this.txbIDCargo.Name = "txbIDCargo";
            this.txbIDCargo.Size = new System.Drawing.Size(101, 20);
            this.txbIDCargo.TabIndex = 3;
            // 
            // lblIDCargo
            // 
            this.lblIDCargo.AutoSize = true;
            this.lblIDCargo.Location = new System.Drawing.Point(34, 70);
            this.lblIDCargo.Name = "lblIDCargo";
            this.lblIDCargo.Size = new System.Drawing.Size(49, 13);
            this.lblIDCargo.TabIndex = 2;
            this.lblIDCargo.Text = "ID Cargo";
            // 
            // txbDataAdmissao
            // 
            this.txbDataAdmissao.Location = new System.Drawing.Point(132, 126);
            this.txbDataAdmissao.Name = "txbDataAdmissao";
            this.txbDataAdmissao.Size = new System.Drawing.Size(101, 20);
            this.txbDataAdmissao.TabIndex = 5;
            // 
            // lblDataAdmissao
            // 
            this.lblDataAdmissao.AutoSize = true;
            this.lblDataAdmissao.Location = new System.Drawing.Point(34, 129);
            this.lblDataAdmissao.Name = "lblDataAdmissao";
            this.lblDataAdmissao.Size = new System.Drawing.Size(92, 13);
            this.lblDataAdmissao.TabIndex = 4;
            this.lblDataAdmissao.Text = "Data de admissão";
            // 
            // txbSalarioHora
            // 
            this.txbSalarioHora.Location = new System.Drawing.Point(108, 188);
            this.txbSalarioHora.Name = "txbSalarioHora";
            this.txbSalarioHora.Size = new System.Drawing.Size(101, 20);
            this.txbSalarioHora.TabIndex = 7;
            // 
            // lblSalarioHora
            // 
            this.lblSalarioHora.AutoSize = true;
            this.lblSalarioHora.Location = new System.Drawing.Point(39, 191);
            this.lblSalarioHora.Name = "lblSalarioHora";
            this.lblSalarioHora.Size = new System.Drawing.Size(63, 13);
            this.lblSalarioHora.TabIndex = 6;
            this.lblSalarioHora.Text = "Salário hora";
            // 
            // txbOperacao
            // 
            this.txbOperacao.Location = new System.Drawing.Point(103, 243);
            this.txbOperacao.Name = "txbOperacao";
            this.txbOperacao.Size = new System.Drawing.Size(101, 20);
            this.txbOperacao.TabIndex = 9;
            // 
            // lblOperacao
            // 
            this.lblOperacao.AutoSize = true;
            this.lblOperacao.Location = new System.Drawing.Point(34, 246);
            this.lblOperacao.Name = "lblOperacao";
            this.lblOperacao.Size = new System.Drawing.Size(54, 13);
            this.lblOperacao.TabIndex = 8;
            this.lblOperacao.Text = "Operação";
            // 
            // txbCargo
            // 
            this.txbCargo.Location = new System.Drawing.Point(329, 67);
            this.txbCargo.Name = "txbCargo";
            this.txbCargo.Size = new System.Drawing.Size(101, 20);
            this.txbCargo.TabIndex = 11;
            // 
            // lblCargo
            // 
            this.lblCargo.AutoSize = true;
            this.lblCargo.Location = new System.Drawing.Point(280, 70);
            this.lblCargo.Name = "lblCargo";
            this.lblCargo.Size = new System.Drawing.Size(35, 13);
            this.lblCargo.TabIndex = 10;
            this.lblCargo.Text = "Cargo";
            // 
            // txbDepartamento
            // 
            this.txbDepartamento.Location = new System.Drawing.Point(592, 63);
            this.txbDepartamento.Name = "txbDepartamento";
            this.txbDepartamento.Size = new System.Drawing.Size(101, 20);
            this.txbDepartamento.TabIndex = 13;
            // 
            // lblDepartamento
            // 
            this.lblDepartamento.AutoSize = true;
            this.lblDepartamento.Location = new System.Drawing.Point(512, 66);
            this.lblDepartamento.Name = "lblDepartamento";
            this.lblDepartamento.Size = new System.Drawing.Size(74, 13);
            this.lblDepartamento.TabIndex = 12;
            this.lblDepartamento.Text = "Departamento";
            // 
            // txbJornadaTrabalho
            // 
            this.txbJornadaTrabalho.Location = new System.Drawing.Point(381, 126);
            this.txbJornadaTrabalho.Name = "txbJornadaTrabalho";
            this.txbJornadaTrabalho.Size = new System.Drawing.Size(101, 20);
            this.txbJornadaTrabalho.TabIndex = 15;
            // 
            // lblJornadaTrabalho
            // 
            this.lblJornadaTrabalho.AutoSize = true;
            this.lblJornadaTrabalho.Location = new System.Drawing.Point(274, 130);
            this.lblJornadaTrabalho.Name = "lblJornadaTrabalho";
            this.lblJornadaTrabalho.Size = new System.Drawing.Size(105, 13);
            this.lblJornadaTrabalho.TabIndex = 14;
            this.lblJornadaTrabalho.Text = "Jornada de Trabalho";
            // 
            // txbSalarioMensal
            // 
            this.txbSalarioMensal.Location = new System.Drawing.Point(578, 127);
            this.txbSalarioMensal.Name = "txbSalarioMensal";
            this.txbSalarioMensal.Size = new System.Drawing.Size(101, 20);
            this.txbSalarioMensal.TabIndex = 17;
            // 
            // lblSalarioMensal
            // 
            this.lblSalarioMensal.AutoSize = true;
            this.lblSalarioMensal.Location = new System.Drawing.Point(495, 131);
            this.lblSalarioMensal.Name = "lblSalarioMensal";
            this.lblSalarioMensal.Size = new System.Drawing.Size(76, 13);
            this.lblSalarioMensal.TabIndex = 16;
            this.lblSalarioMensal.Text = "Salário Mensal";
            // 
            // txbAgencia
            // 
            this.txbAgencia.Location = new System.Drawing.Point(282, 188);
            this.txbAgencia.Name = "txbAgencia";
            this.txbAgencia.Size = new System.Drawing.Size(101, 20);
            this.txbAgencia.TabIndex = 19;
            // 
            // lblAgencia
            // 
            this.lblAgencia.AutoSize = true;
            this.lblAgencia.Location = new System.Drawing.Point(227, 192);
            this.lblAgencia.Name = "lblAgencia";
            this.lblAgencia.Size = new System.Drawing.Size(46, 13);
            this.lblAgencia.TabIndex = 18;
            this.lblAgencia.Text = "Agencia";
            // 
            // txbConta
            // 
            this.txbConta.Location = new System.Drawing.Point(470, 191);
            this.txbConta.Name = "txbConta";
            this.txbConta.Size = new System.Drawing.Size(101, 20);
            this.txbConta.TabIndex = 21;
            // 
            // lblConta
            // 
            this.lblConta.AutoSize = true;
            this.lblConta.Location = new System.Drawing.Point(415, 195);
            this.lblConta.Name = "lblConta";
            this.lblConta.Size = new System.Drawing.Size(35, 13);
            this.lblConta.TabIndex = 20;
            this.lblConta.Text = "Conta";
            // 
            // txbBanco
            // 
            this.txbBanco.Location = new System.Drawing.Point(637, 189);
            this.txbBanco.Name = "txbBanco";
            this.txbBanco.Size = new System.Drawing.Size(101, 20);
            this.txbBanco.TabIndex = 23;
            // 
            // lblBanco
            // 
            this.lblBanco.AutoSize = true;
            this.lblBanco.Location = new System.Drawing.Point(582, 193);
            this.lblBanco.Name = "lblBanco";
            this.lblBanco.Size = new System.Drawing.Size(38, 13);
            this.lblBanco.TabIndex = 22;
            this.lblBanco.Text = "Banco";
            // 
            // btnProximo
            // 
            this.btnProximo.Location = new System.Drawing.Point(477, 348);
            this.btnProximo.Name = "btnProximo";
            this.btnProximo.Size = new System.Drawing.Size(75, 23);
            this.btnProximo.TabIndex = 69;
            this.btnProximo.Text = "Próximo";
            this.btnProximo.UseVisualStyleBackColor = true;
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(329, 348);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(75, 23);
            this.btnLimpar.TabIndex = 68;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(211, 348);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(75, 23);
            this.btnCancelar.TabIndex = 67;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            // 
            // frmCadastroCargosDadosBancarios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnProximo);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.txbBanco);
            this.Controls.Add(this.lblBanco);
            this.Controls.Add(this.txbConta);
            this.Controls.Add(this.lblConta);
            this.Controls.Add(this.txbAgencia);
            this.Controls.Add(this.lblAgencia);
            this.Controls.Add(this.txbSalarioMensal);
            this.Controls.Add(this.lblSalarioMensal);
            this.Controls.Add(this.txbJornadaTrabalho);
            this.Controls.Add(this.lblJornadaTrabalho);
            this.Controls.Add(this.txbDepartamento);
            this.Controls.Add(this.lblDepartamento);
            this.Controls.Add(this.txbCargo);
            this.Controls.Add(this.lblCargo);
            this.Controls.Add(this.txbOperacao);
            this.Controls.Add(this.lblOperacao);
            this.Controls.Add(this.txbSalarioHora);
            this.Controls.Add(this.lblSalarioHora);
            this.Controls.Add(this.txbDataAdmissao);
            this.Controls.Add(this.lblDataAdmissao);
            this.Controls.Add(this.txbIDCargo);
            this.Controls.Add(this.lblIDCargo);
            this.Name = "frmCadastroCargosDadosBancarios";
            this.Text = "Cadastro de Cargos e Dados Bancários";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txbIDCargo;
        private System.Windows.Forms.Label lblIDCargo;
        private System.Windows.Forms.TextBox txbDataAdmissao;
        private System.Windows.Forms.Label lblDataAdmissao;
        private System.Windows.Forms.TextBox txbSalarioHora;
        private System.Windows.Forms.Label lblSalarioHora;
        private System.Windows.Forms.TextBox txbOperacao;
        private System.Windows.Forms.Label lblOperacao;
        private System.Windows.Forms.TextBox txbCargo;
        private System.Windows.Forms.Label lblCargo;
        private System.Windows.Forms.TextBox txbDepartamento;
        private System.Windows.Forms.Label lblDepartamento;
        private System.Windows.Forms.TextBox txbJornadaTrabalho;
        private System.Windows.Forms.Label lblJornadaTrabalho;
        private System.Windows.Forms.TextBox txbSalarioMensal;
        private System.Windows.Forms.Label lblSalarioMensal;
        private System.Windows.Forms.TextBox txbAgencia;
        private System.Windows.Forms.Label lblAgencia;
        private System.Windows.Forms.TextBox txbConta;
        private System.Windows.Forms.Label lblConta;
        private System.Windows.Forms.TextBox txbBanco;
        private System.Windows.Forms.Label lblBanco;
        private System.Windows.Forms.Button btnProximo;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnCancelar;
    }
}