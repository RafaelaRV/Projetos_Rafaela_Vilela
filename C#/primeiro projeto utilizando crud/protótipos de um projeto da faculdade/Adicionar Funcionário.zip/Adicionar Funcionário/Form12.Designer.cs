﻿namespace Adicionar_Funcionário
{
    partial class frmApagarFuncionario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnApagarFuncionario = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.txbBanco = new System.Windows.Forms.TextBox();
            this.lblBanco = new System.Windows.Forms.Label();
            this.txbConta = new System.Windows.Forms.TextBox();
            this.lblConta = new System.Windows.Forms.Label();
            this.txbAgencia = new System.Windows.Forms.TextBox();
            this.lblAgencia = new System.Windows.Forms.Label();
            this.txbSalarioMensal = new System.Windows.Forms.TextBox();
            this.lblSalarioMensal = new System.Windows.Forms.Label();
            this.txbJornadaTrabalho = new System.Windows.Forms.TextBox();
            this.lblJornadaTrabalho = new System.Windows.Forms.Label();
            this.txbDepartamento = new System.Windows.Forms.TextBox();
            this.lblDepartamento = new System.Windows.Forms.Label();
            this.txbCargo = new System.Windows.Forms.TextBox();
            this.lblCargo = new System.Windows.Forms.Label();
            this.txbOperacao = new System.Windows.Forms.TextBox();
            this.lblOperacao = new System.Windows.Forms.Label();
            this.txbSalarioHora = new System.Windows.Forms.TextBox();
            this.lblSalarioHora = new System.Windows.Forms.Label();
            this.txbDataAdmissao = new System.Windows.Forms.TextBox();
            this.lblDataAdmissao = new System.Windows.Forms.Label();
            this.txbIDCargo = new System.Windows.Forms.TextBox();
            this.lblIDCargo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnApagarFuncionario
            // 
            this.btnApagarFuncionario.Location = new System.Drawing.Point(287, 344);
            this.btnApagarFuncionario.Name = "btnApagarFuncionario";
            this.btnApagarFuncionario.Size = new System.Drawing.Size(75, 23);
            this.btnApagarFuncionario.TabIndex = 94;
            this.btnApagarFuncionario.Text = "Apagar";
            this.btnApagarFuncionario.UseVisualStyleBackColor = true;
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(445, 344);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(75, 23);
            this.btnCancelar.TabIndex = 92;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            // 
            // txbBanco
            // 
            this.txbBanco.Location = new System.Drawing.Point(640, 173);
            this.txbBanco.Name = "txbBanco";
            this.txbBanco.Size = new System.Drawing.Size(101, 20);
            this.txbBanco.TabIndex = 91;
            // 
            // lblBanco
            // 
            this.lblBanco.AutoSize = true;
            this.lblBanco.Location = new System.Drawing.Point(585, 177);
            this.lblBanco.Name = "lblBanco";
            this.lblBanco.Size = new System.Drawing.Size(38, 13);
            this.lblBanco.TabIndex = 90;
            this.lblBanco.Text = "Banco";
            // 
            // txbConta
            // 
            this.txbConta.Location = new System.Drawing.Point(473, 175);
            this.txbConta.Name = "txbConta";
            this.txbConta.Size = new System.Drawing.Size(101, 20);
            this.txbConta.TabIndex = 89;
            // 
            // lblConta
            // 
            this.lblConta.AutoSize = true;
            this.lblConta.Location = new System.Drawing.Point(418, 179);
            this.lblConta.Name = "lblConta";
            this.lblConta.Size = new System.Drawing.Size(35, 13);
            this.lblConta.TabIndex = 88;
            this.lblConta.Text = "Conta";
            // 
            // txbAgencia
            // 
            this.txbAgencia.Location = new System.Drawing.Point(285, 172);
            this.txbAgencia.Name = "txbAgencia";
            this.txbAgencia.Size = new System.Drawing.Size(101, 20);
            this.txbAgencia.TabIndex = 87;
            // 
            // lblAgencia
            // 
            this.lblAgencia.AutoSize = true;
            this.lblAgencia.Location = new System.Drawing.Point(230, 176);
            this.lblAgencia.Name = "lblAgencia";
            this.lblAgencia.Size = new System.Drawing.Size(46, 13);
            this.lblAgencia.TabIndex = 86;
            this.lblAgencia.Text = "Agencia";
            // 
            // txbSalarioMensal
            // 
            this.txbSalarioMensal.Location = new System.Drawing.Point(581, 111);
            this.txbSalarioMensal.Name = "txbSalarioMensal";
            this.txbSalarioMensal.Size = new System.Drawing.Size(101, 20);
            this.txbSalarioMensal.TabIndex = 85;
            // 
            // lblSalarioMensal
            // 
            this.lblSalarioMensal.AutoSize = true;
            this.lblSalarioMensal.Location = new System.Drawing.Point(498, 115);
            this.lblSalarioMensal.Name = "lblSalarioMensal";
            this.lblSalarioMensal.Size = new System.Drawing.Size(76, 13);
            this.lblSalarioMensal.TabIndex = 84;
            this.lblSalarioMensal.Text = "Salário Mensal";
            // 
            // txbJornadaTrabalho
            // 
            this.txbJornadaTrabalho.Location = new System.Drawing.Point(384, 110);
            this.txbJornadaTrabalho.Name = "txbJornadaTrabalho";
            this.txbJornadaTrabalho.Size = new System.Drawing.Size(101, 20);
            this.txbJornadaTrabalho.TabIndex = 83;
            // 
            // lblJornadaTrabalho
            // 
            this.lblJornadaTrabalho.AutoSize = true;
            this.lblJornadaTrabalho.Location = new System.Drawing.Point(277, 114);
            this.lblJornadaTrabalho.Name = "lblJornadaTrabalho";
            this.lblJornadaTrabalho.Size = new System.Drawing.Size(105, 13);
            this.lblJornadaTrabalho.TabIndex = 82;
            this.lblJornadaTrabalho.Text = "Jornada de Trabalho";
            // 
            // txbDepartamento
            // 
            this.txbDepartamento.Location = new System.Drawing.Point(595, 47);
            this.txbDepartamento.Name = "txbDepartamento";
            this.txbDepartamento.Size = new System.Drawing.Size(101, 20);
            this.txbDepartamento.TabIndex = 81;
            // 
            // lblDepartamento
            // 
            this.lblDepartamento.AutoSize = true;
            this.lblDepartamento.Location = new System.Drawing.Point(515, 50);
            this.lblDepartamento.Name = "lblDepartamento";
            this.lblDepartamento.Size = new System.Drawing.Size(74, 13);
            this.lblDepartamento.TabIndex = 80;
            this.lblDepartamento.Text = "Departamento";
            // 
            // txbCargo
            // 
            this.txbCargo.Location = new System.Drawing.Point(332, 51);
            this.txbCargo.Name = "txbCargo";
            this.txbCargo.Size = new System.Drawing.Size(101, 20);
            this.txbCargo.TabIndex = 79;
            // 
            // lblCargo
            // 
            this.lblCargo.AutoSize = true;
            this.lblCargo.Location = new System.Drawing.Point(283, 54);
            this.lblCargo.Name = "lblCargo";
            this.lblCargo.Size = new System.Drawing.Size(35, 13);
            this.lblCargo.TabIndex = 78;
            this.lblCargo.Text = "Cargo";
            // 
            // txbOperacao
            // 
            this.txbOperacao.Location = new System.Drawing.Point(106, 227);
            this.txbOperacao.Name = "txbOperacao";
            this.txbOperacao.Size = new System.Drawing.Size(101, 20);
            this.txbOperacao.TabIndex = 77;
            // 
            // lblOperacao
            // 
            this.lblOperacao.AutoSize = true;
            this.lblOperacao.Location = new System.Drawing.Point(37, 230);
            this.lblOperacao.Name = "lblOperacao";
            this.lblOperacao.Size = new System.Drawing.Size(54, 13);
            this.lblOperacao.TabIndex = 76;
            this.lblOperacao.Text = "Operação";
            // 
            // txbSalarioHora
            // 
            this.txbSalarioHora.Location = new System.Drawing.Point(111, 172);
            this.txbSalarioHora.Name = "txbSalarioHora";
            this.txbSalarioHora.Size = new System.Drawing.Size(101, 20);
            this.txbSalarioHora.TabIndex = 75;
            // 
            // lblSalarioHora
            // 
            this.lblSalarioHora.AutoSize = true;
            this.lblSalarioHora.Location = new System.Drawing.Point(42, 175);
            this.lblSalarioHora.Name = "lblSalarioHora";
            this.lblSalarioHora.Size = new System.Drawing.Size(63, 13);
            this.lblSalarioHora.TabIndex = 74;
            this.lblSalarioHora.Text = "Salário hora";
            // 
            // txbDataAdmissao
            // 
            this.txbDataAdmissao.Location = new System.Drawing.Point(135, 110);
            this.txbDataAdmissao.Name = "txbDataAdmissao";
            this.txbDataAdmissao.Size = new System.Drawing.Size(101, 20);
            this.txbDataAdmissao.TabIndex = 73;
            // 
            // lblDataAdmissao
            // 
            this.lblDataAdmissao.AutoSize = true;
            this.lblDataAdmissao.Location = new System.Drawing.Point(37, 113);
            this.lblDataAdmissao.Name = "lblDataAdmissao";
            this.lblDataAdmissao.Size = new System.Drawing.Size(92, 13);
            this.lblDataAdmissao.TabIndex = 72;
            this.lblDataAdmissao.Text = "Data de admissão";
            // 
            // txbIDCargo
            // 
            this.txbIDCargo.Location = new System.Drawing.Point(92, 50);
            this.txbIDCargo.Name = "txbIDCargo";
            this.txbIDCargo.Size = new System.Drawing.Size(101, 20);
            this.txbIDCargo.TabIndex = 71;
            // 
            // lblIDCargo
            // 
            this.lblIDCargo.AutoSize = true;
            this.lblIDCargo.Location = new System.Drawing.Point(37, 54);
            this.lblIDCargo.Name = "lblIDCargo";
            this.lblIDCargo.Size = new System.Drawing.Size(49, 13);
            this.lblIDCargo.TabIndex = 70;
            this.lblIDCargo.Text = "ID Cargo";
            // 
            // frmApagarFuncionario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnApagarFuncionario);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.txbBanco);
            this.Controls.Add(this.lblBanco);
            this.Controls.Add(this.txbConta);
            this.Controls.Add(this.lblConta);
            this.Controls.Add(this.txbAgencia);
            this.Controls.Add(this.lblAgencia);
            this.Controls.Add(this.txbSalarioMensal);
            this.Controls.Add(this.lblSalarioMensal);
            this.Controls.Add(this.txbJornadaTrabalho);
            this.Controls.Add(this.lblJornadaTrabalho);
            this.Controls.Add(this.txbDepartamento);
            this.Controls.Add(this.lblDepartamento);
            this.Controls.Add(this.txbCargo);
            this.Controls.Add(this.lblCargo);
            this.Controls.Add(this.txbOperacao);
            this.Controls.Add(this.lblOperacao);
            this.Controls.Add(this.txbSalarioHora);
            this.Controls.Add(this.lblSalarioHora);
            this.Controls.Add(this.txbDataAdmissao);
            this.Controls.Add(this.lblDataAdmissao);
            this.Controls.Add(this.txbIDCargo);
            this.Controls.Add(this.lblIDCargo);
            this.Name = "frmApagarFuncionario";
            this.Text = "Apagar Funcionário";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnApagarFuncionario;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.TextBox txbBanco;
        private System.Windows.Forms.Label lblBanco;
        private System.Windows.Forms.TextBox txbConta;
        private System.Windows.Forms.Label lblConta;
        private System.Windows.Forms.TextBox txbAgencia;
        private System.Windows.Forms.Label lblAgencia;
        private System.Windows.Forms.TextBox txbSalarioMensal;
        private System.Windows.Forms.Label lblSalarioMensal;
        private System.Windows.Forms.TextBox txbJornadaTrabalho;
        private System.Windows.Forms.Label lblJornadaTrabalho;
        private System.Windows.Forms.TextBox txbDepartamento;
        private System.Windows.Forms.Label lblDepartamento;
        private System.Windows.Forms.TextBox txbCargo;
        private System.Windows.Forms.Label lblCargo;
        private System.Windows.Forms.TextBox txbOperacao;
        private System.Windows.Forms.Label lblOperacao;
        private System.Windows.Forms.TextBox txbSalarioHora;
        private System.Windows.Forms.Label lblSalarioHora;
        private System.Windows.Forms.TextBox txbDataAdmissao;
        private System.Windows.Forms.Label lblDataAdmissao;
        private System.Windows.Forms.TextBox txbIDCargo;
        private System.Windows.Forms.Label lblIDCargo;
    }
}