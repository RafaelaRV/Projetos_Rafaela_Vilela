﻿namespace Adicionar_Funcionário
{
    partial class frmEditarFuncionario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txbUF = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txbBairro = new System.Windows.Forms.TextBox();
            this.txbNumero = new System.Windows.Forms.TextBox();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnProximo = new System.Windows.Forms.Button();
            this.txbogradouro = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txbCEP = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txbCPF = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txbPIS = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txbNacionalidade = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txbEstadoCivil = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txbGenero = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txbTelefone = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txbEndereço = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txbRG = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txbDataNascimento = new System.Windows.Forms.TextBox();
            this.lblDataNascimento = new System.Windows.Forms.Label();
            this.txbNomeCompleto = new System.Windows.Forms.TextBox();
            this.lblNomeCompleto = new System.Windows.Forms.Label();
            this.txbID = new System.Windows.Forms.TextBox();
            this.lblID = new System.Windows.Forms.Label();
            this.txbEmail = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txbUF
            // 
            this.txbUF.Location = new System.Drawing.Point(713, 241);
            this.txbUF.Name = "txbUF";
            this.txbUF.Size = new System.Drawing.Size(47, 20);
            this.txbUF.TabIndex = 87;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(686, 245);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(21, 13);
            this.label14.TabIndex = 86;
            this.label14.Text = "UF";
            // 
            // txbBairro
            // 
            this.txbBairro.ForeColor = System.Drawing.Color.Gray;
            this.txbBairro.Location = new System.Drawing.Point(569, 242);
            this.txbBairro.Name = "txbBairro";
            this.txbBairro.Size = new System.Drawing.Size(100, 20);
            this.txbBairro.TabIndex = 85;
            this.txbBairro.Text = "Bairro";
            // 
            // txbNumero
            // 
            this.txbNumero.ForeColor = System.Drawing.Color.Gray;
            this.txbNumero.Location = new System.Drawing.Point(472, 242);
            this.txbNumero.Name = "txbNumero";
            this.txbNumero.Size = new System.Drawing.Size(71, 20);
            this.txbNumero.TabIndex = 84;
            this.txbNumero.Text = "Numero";
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(208, 371);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(75, 23);
            this.btnCancelar.TabIndex = 83;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(302, 371);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(75, 23);
            this.btnLimpar.TabIndex = 82;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            // 
            // btnProximo
            // 
            this.btnProximo.Location = new System.Drawing.Point(383, 371);
            this.btnProximo.Name = "btnProximo";
            this.btnProximo.Size = new System.Drawing.Size(75, 23);
            this.btnProximo.TabIndex = 81;
            this.btnProximo.Text = "Próximo";
            this.btnProximo.UseVisualStyleBackColor = true;
            // 
            // txbogradouro
            // 
            this.txbogradouro.Location = new System.Drawing.Point(506, 287);
            this.txbogradouro.Name = "txbogradouro";
            this.txbogradouro.Size = new System.Drawing.Size(100, 20);
            this.txbogradouro.TabIndex = 80;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(443, 290);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(61, 13);
            this.label13.TabIndex = 79;
            this.label13.Text = "Logradouro";
            // 
            // txbCEP
            // 
            this.txbCEP.Location = new System.Drawing.Point(289, 287);
            this.txbCEP.Name = "txbCEP";
            this.txbCEP.Size = new System.Drawing.Size(100, 20);
            this.txbCEP.TabIndex = 78;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(255, 290);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(28, 13);
            this.label12.TabIndex = 77;
            this.label12.Text = "CEP";
            // 
            // txbCPF
            // 
            this.txbCPF.Location = new System.Drawing.Point(443, 190);
            this.txbCPF.Name = "txbCPF";
            this.txbCPF.Size = new System.Drawing.Size(100, 20);
            this.txbCPF.TabIndex = 76;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(411, 193);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(27, 13);
            this.label11.TabIndex = 75;
            this.label11.Text = "CPF";
            // 
            // txbPIS
            // 
            this.txbPIS.Location = new System.Drawing.Point(254, 190);
            this.txbPIS.Name = "txbPIS";
            this.txbPIS.Size = new System.Drawing.Size(100, 20);
            this.txbPIS.TabIndex = 74;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(222, 193);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(24, 13);
            this.label10.TabIndex = 73;
            this.label10.Text = "PIS";
            // 
            // txbNacionalidade
            // 
            this.txbNacionalidade.Location = new System.Drawing.Point(643, 141);
            this.txbNacionalidade.Name = "txbNacionalidade";
            this.txbNacionalidade.Size = new System.Drawing.Size(100, 20);
            this.txbNacionalidade.TabIndex = 72;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(566, 144);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(75, 13);
            this.label9.TabIndex = 71;
            this.label9.Text = "Nacionalidade";
            // 
            // txbEstadoCivil
            // 
            this.txbEstadoCivil.Location = new System.Drawing.Point(443, 138);
            this.txbEstadoCivil.Name = "txbEstadoCivil";
            this.txbEstadoCivil.Size = new System.Drawing.Size(100, 20);
            this.txbEstadoCivil.TabIndex = 70;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(380, 141);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(62, 13);
            this.label8.TabIndex = 69;
            this.label8.Text = "Estavo Civil";
            // 
            // txbGenero
            // 
            this.txbGenero.Location = new System.Drawing.Point(316, 138);
            this.txbGenero.Name = "txbGenero";
            this.txbGenero.Size = new System.Drawing.Size(38, 20);
            this.txbGenero.TabIndex = 68;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(272, 141);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 13);
            this.label7.TabIndex = 67;
            this.label7.Text = "Genero";
            // 
            // txbTelefone
            // 
            this.txbTelefone.Location = new System.Drawing.Point(91, 284);
            this.txbTelefone.Name = "txbTelefone";
            this.txbTelefone.Size = new System.Drawing.Size(100, 20);
            this.txbTelefone.TabIndex = 66;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(40, 287);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 13);
            this.label6.TabIndex = 65;
            this.label6.Text = "Telefone";
            // 
            // txbEndereço
            // 
            this.txbEndereço.ForeColor = System.Drawing.SystemColors.GrayText;
            this.txbEndereço.Location = new System.Drawing.Point(94, 242);
            this.txbEndereço.Name = "txbEndereço";
            this.txbEndereço.Size = new System.Drawing.Size(351, 20);
            this.txbEndereço.TabIndex = 64;
            this.txbEndereço.Text = "Rua";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(40, 245);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 13);
            this.label5.TabIndex = 63;
            this.label5.Text = "Endereço";
            // 
            // txbRG
            // 
            this.txbRG.Location = new System.Drawing.Point(72, 192);
            this.txbRG.Name = "txbRG";
            this.txbRG.Size = new System.Drawing.Size(100, 20);
            this.txbRG.TabIndex = 62;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(40, 195);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(23, 13);
            this.label4.TabIndex = 61;
            this.label4.Text = "RG";
            // 
            // txbDataNascimento
            // 
            this.txbDataNascimento.Location = new System.Drawing.Point(144, 138);
            this.txbDataNascimento.Name = "txbDataNascimento";
            this.txbDataNascimento.Size = new System.Drawing.Size(100, 20);
            this.txbDataNascimento.TabIndex = 60;
            // 
            // lblDataNascimento
            // 
            this.lblDataNascimento.AutoSize = true;
            this.lblDataNascimento.Location = new System.Drawing.Point(40, 141);
            this.lblDataNascimento.Name = "lblDataNascimento";
            this.lblDataNascimento.Size = new System.Drawing.Size(104, 13);
            this.lblDataNascimento.TabIndex = 59;
            this.lblDataNascimento.Text = "Data de Nascimento";
            // 
            // txbNomeCompleto
            // 
            this.txbNomeCompleto.Location = new System.Drawing.Point(290, 75);
            this.txbNomeCompleto.Name = "txbNomeCompleto";
            this.txbNomeCompleto.Size = new System.Drawing.Size(269, 20);
            this.txbNomeCompleto.TabIndex = 58;
            // 
            // lblNomeCompleto
            // 
            this.lblNomeCompleto.AutoSize = true;
            this.lblNomeCompleto.Location = new System.Drawing.Point(206, 78);
            this.lblNomeCompleto.Name = "lblNomeCompleto";
            this.lblNomeCompleto.Size = new System.Drawing.Size(82, 13);
            this.lblNomeCompleto.TabIndex = 57;
            this.lblNomeCompleto.Text = "Nome Completo";
            // 
            // txbID
            // 
            this.txbID.Location = new System.Drawing.Point(72, 79);
            this.txbID.Name = "txbID";
            this.txbID.Size = new System.Drawing.Size(50, 20);
            this.txbID.TabIndex = 56;
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Location = new System.Drawing.Point(40, 82);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(18, 13);
            this.lblID.TabIndex = 55;
            this.lblID.Text = "ID";
            // 
            // txbEmail
            // 
            this.txbEmail.Location = new System.Drawing.Point(91, 328);
            this.txbEmail.Name = "txbEmail";
            this.txbEmail.Size = new System.Drawing.Size(100, 20);
            this.txbEmail.TabIndex = 89;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(40, 331);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(35, 13);
            this.lblEmail.TabIndex = 88;
            this.lblEmail.Text = "E-mail";
            // 
            // frmEditarFuncionario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txbEmail);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.txbUF);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txbBairro);
            this.Controls.Add(this.txbNumero);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnProximo);
            this.Controls.Add(this.txbogradouro);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txbCEP);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txbCPF);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txbPIS);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txbNacionalidade);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txbEstadoCivil);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txbGenero);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txbTelefone);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txbEndereço);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txbRG);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txbDataNascimento);
            this.Controls.Add(this.lblDataNascimento);
            this.Controls.Add(this.txbNomeCompleto);
            this.Controls.Add(this.lblNomeCompleto);
            this.Controls.Add(this.txbID);
            this.Controls.Add(this.lblID);
            this.Name = "frmEditarFuncionario";
            this.Text = "Editar Funcionário";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txbUF;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txbBairro;
        private System.Windows.Forms.TextBox txbNumero;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnProximo;
        private System.Windows.Forms.TextBox txbogradouro;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txbCEP;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txbCPF;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txbPIS;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txbNacionalidade;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txbEstadoCivil;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txbGenero;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txbTelefone;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txbEndereço;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txbRG;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txbDataNascimento;
        private System.Windows.Forms.Label lblDataNascimento;
        private System.Windows.Forms.TextBox txbNomeCompleto;
        private System.Windows.Forms.Label lblNomeCompleto;
        private System.Windows.Forms.TextBox txbID;
        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.TextBox txbEmail;
        private System.Windows.Forms.Label lblEmail;
    }
}