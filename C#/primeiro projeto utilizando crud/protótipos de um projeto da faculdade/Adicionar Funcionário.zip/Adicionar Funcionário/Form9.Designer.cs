﻿namespace Adicionar_Funcionário
{
    partial class frmEditarDependentes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnProximo = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.txbGrauParentesco = new System.Windows.Forms.TextBox();
            this.lblGrauParentesco = new System.Windows.Forms.Label();
            this.txbUF = new System.Windows.Forms.TextBox();
            this.lblUF = new System.Windows.Forms.Label();
            this.txbBairro = new System.Windows.Forms.TextBox();
            this.txbNumero = new System.Windows.Forms.TextBox();
            this.txbEndereco = new System.Windows.Forms.TextBox();
            this.lblEndereco = new System.Windows.Forms.Label();
            this.txbNomeCompleto = new System.Windows.Forms.TextBox();
            this.lblNomeCompleto = new System.Windows.Forms.Label();
            this.txbCodigoDependentes = new System.Windows.Forms.TextBox();
            this.lblCodigoDependentes = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnProximo
            // 
            this.btnProximo.Location = new System.Drawing.Point(444, 362);
            this.btnProximo.Name = "btnProximo";
            this.btnProximo.Size = new System.Drawing.Size(75, 23);
            this.btnProximo.TabIndex = 82;
            this.btnProximo.Text = "Próximo";
            this.btnProximo.UseVisualStyleBackColor = true;
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(296, 362);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(75, 23);
            this.btnLimpar.TabIndex = 80;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(178, 362);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(75, 23);
            this.btnCancelar.TabIndex = 79;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            // 
            // txbGrauParentesco
            // 
            this.txbGrauParentesco.Location = new System.Drawing.Point(137, 254);
            this.txbGrauParentesco.Name = "txbGrauParentesco";
            this.txbGrauParentesco.Size = new System.Drawing.Size(269, 20);
            this.txbGrauParentesco.TabIndex = 78;
            // 
            // lblGrauParentesco
            // 
            this.lblGrauParentesco.AutoSize = true;
            this.lblGrauParentesco.Location = new System.Drawing.Point(33, 257);
            this.lblGrauParentesco.Name = "lblGrauParentesco";
            this.lblGrauParentesco.Size = new System.Drawing.Size(102, 13);
            this.lblGrauParentesco.TabIndex = 77;
            this.lblGrauParentesco.Text = "Grau de Parentesco";
            // 
            // txbUF
            // 
            this.txbUF.Location = new System.Drawing.Point(699, 165);
            this.txbUF.Name = "txbUF";
            this.txbUF.Size = new System.Drawing.Size(47, 20);
            this.txbUF.TabIndex = 76;
            // 
            // lblUF
            // 
            this.lblUF.AutoSize = true;
            this.lblUF.Location = new System.Drawing.Point(672, 169);
            this.lblUF.Name = "lblUF";
            this.lblUF.Size = new System.Drawing.Size(21, 13);
            this.lblUF.TabIndex = 75;
            this.lblUF.Text = "UF";
            // 
            // txbBairro
            // 
            this.txbBairro.ForeColor = System.Drawing.Color.Gray;
            this.txbBairro.Location = new System.Drawing.Point(555, 166);
            this.txbBairro.Name = "txbBairro";
            this.txbBairro.Size = new System.Drawing.Size(100, 20);
            this.txbBairro.TabIndex = 74;
            this.txbBairro.Text = "Bairro";
            // 
            // txbNumero
            // 
            this.txbNumero.ForeColor = System.Drawing.Color.Gray;
            this.txbNumero.Location = new System.Drawing.Point(458, 166);
            this.txbNumero.Name = "txbNumero";
            this.txbNumero.Size = new System.Drawing.Size(71, 20);
            this.txbNumero.TabIndex = 73;
            this.txbNumero.Text = "Numero";
            // 
            // txbEndereco
            // 
            this.txbEndereco.ForeColor = System.Drawing.Color.Gray;
            this.txbEndereco.Location = new System.Drawing.Point(80, 166);
            this.txbEndereco.Name = "txbEndereco";
            this.txbEndereco.Size = new System.Drawing.Size(351, 20);
            this.txbEndereco.TabIndex = 72;
            this.txbEndereco.Text = "Rua";
            // 
            // lblEndereco
            // 
            this.lblEndereco.AutoSize = true;
            this.lblEndereco.Location = new System.Drawing.Point(26, 169);
            this.lblEndereco.Name = "lblEndereco";
            this.lblEndereco.Size = new System.Drawing.Size(53, 13);
            this.lblEndereco.TabIndex = 71;
            this.lblEndereco.Text = "Endereço";
            // 
            // txbNomeCompleto
            // 
            this.txbNomeCompleto.Location = new System.Drawing.Point(411, 69);
            this.txbNomeCompleto.Name = "txbNomeCompleto";
            this.txbNomeCompleto.Size = new System.Drawing.Size(269, 20);
            this.txbNomeCompleto.TabIndex = 70;
            // 
            // lblNomeCompleto
            // 
            this.lblNomeCompleto.AutoSize = true;
            this.lblNomeCompleto.Location = new System.Drawing.Point(327, 72);
            this.lblNomeCompleto.Name = "lblNomeCompleto";
            this.lblNomeCompleto.Size = new System.Drawing.Size(82, 13);
            this.lblNomeCompleto.TabIndex = 69;
            this.lblNomeCompleto.Text = "Nome Completo";
            // 
            // txbCodigoDependentes
            // 
            this.txbCodigoDependentes.Location = new System.Drawing.Point(152, 72);
            this.txbCodigoDependentes.Name = "txbCodigoDependentes";
            this.txbCodigoDependentes.Size = new System.Drawing.Size(101, 20);
            this.txbCodigoDependentes.TabIndex = 68;
            // 
            // lblCodigoDependentes
            // 
            this.lblCodigoDependentes.AutoSize = true;
            this.lblCodigoDependentes.Location = new System.Drawing.Point(28, 75);
            this.lblCodigoDependentes.Name = "lblCodigoDependentes";
            this.lblCodigoDependentes.Size = new System.Drawing.Size(122, 13);
            this.lblCodigoDependentes.TabIndex = 67;
            this.lblCodigoDependentes.Text = "Código de Dependentes";
            // 
            // frmEditarDependentes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnProximo);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.txbGrauParentesco);
            this.Controls.Add(this.lblGrauParentesco);
            this.Controls.Add(this.txbUF);
            this.Controls.Add(this.lblUF);
            this.Controls.Add(this.txbBairro);
            this.Controls.Add(this.txbNumero);
            this.Controls.Add(this.txbEndereco);
            this.Controls.Add(this.lblEndereco);
            this.Controls.Add(this.txbNomeCompleto);
            this.Controls.Add(this.lblNomeCompleto);
            this.Controls.Add(this.txbCodigoDependentes);
            this.Controls.Add(this.lblCodigoDependentes);
            this.Name = "frmEditarDependentes";
            this.Text = "Editar Dependentes";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnProximo;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.TextBox txbGrauParentesco;
        private System.Windows.Forms.Label lblGrauParentesco;
        private System.Windows.Forms.TextBox txbUF;
        private System.Windows.Forms.Label lblUF;
        private System.Windows.Forms.TextBox txbBairro;
        private System.Windows.Forms.TextBox txbNumero;
        private System.Windows.Forms.TextBox txbEndereco;
        private System.Windows.Forms.Label lblEndereco;
        private System.Windows.Forms.TextBox txbNomeCompleto;
        private System.Windows.Forms.Label lblNomeCompleto;
        private System.Windows.Forms.TextBox txbCodigoDependentes;
        private System.Windows.Forms.Label lblCodigoDependentes;
    }
}