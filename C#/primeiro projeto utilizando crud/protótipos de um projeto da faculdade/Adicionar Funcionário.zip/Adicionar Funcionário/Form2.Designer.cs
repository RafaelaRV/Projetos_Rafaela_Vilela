﻿namespace Adicionar_Funcionário
{
    partial class frmCadastroDependentes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCodigoDependentes = new System.Windows.Forms.Label();
            this.txbCodigoDependentes = new System.Windows.Forms.TextBox();
            this.txbNomeCompleto = new System.Windows.Forms.TextBox();
            this.lblNomeCompleto = new System.Windows.Forms.Label();
            this.txbUF = new System.Windows.Forms.TextBox();
            this.lblUF = new System.Windows.Forms.Label();
            this.txbBairro = new System.Windows.Forms.TextBox();
            this.txbNumero = new System.Windows.Forms.TextBox();
            this.txbEndereco = new System.Windows.Forms.TextBox();
            this.lblEndereco = new System.Windows.Forms.Label();
            this.txbGrauParentesco = new System.Windows.Forms.TextBox();
            this.lblGrauParentesco = new System.Windows.Forms.Label();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnNovoParentesco = new System.Windows.Forms.Button();
            this.btnProximo = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblCodigoDependentes
            // 
            this.lblCodigoDependentes.AutoSize = true;
            this.lblCodigoDependentes.Location = new System.Drawing.Point(24, 63);
            this.lblCodigoDependentes.Name = "lblCodigoDependentes";
            this.lblCodigoDependentes.Size = new System.Drawing.Size(122, 13);
            this.lblCodigoDependentes.TabIndex = 0;
            this.lblCodigoDependentes.Text = "Código de Dependentes";
            // 
            // txbCodigoDependentes
            // 
            this.txbCodigoDependentes.Location = new System.Drawing.Point(148, 60);
            this.txbCodigoDependentes.Name = "txbCodigoDependentes";
            this.txbCodigoDependentes.Size = new System.Drawing.Size(101, 20);
            this.txbCodigoDependentes.TabIndex = 1;
            // 
            // txbNomeCompleto
            // 
            this.txbNomeCompleto.Location = new System.Drawing.Point(407, 57);
            this.txbNomeCompleto.Name = "txbNomeCompleto";
            this.txbNomeCompleto.Size = new System.Drawing.Size(269, 20);
            this.txbNomeCompleto.TabIndex = 3;
            // 
            // lblNomeCompleto
            // 
            this.lblNomeCompleto.AutoSize = true;
            this.lblNomeCompleto.Location = new System.Drawing.Point(323, 60);
            this.lblNomeCompleto.Name = "lblNomeCompleto";
            this.lblNomeCompleto.Size = new System.Drawing.Size(82, 13);
            this.lblNomeCompleto.TabIndex = 2;
            this.lblNomeCompleto.Text = "Nome Completo";
            // 
            // txbUF
            // 
            this.txbUF.Location = new System.Drawing.Point(695, 153);
            this.txbUF.Name = "txbUF";
            this.txbUF.Size = new System.Drawing.Size(47, 20);
            this.txbUF.TabIndex = 60;
            // 
            // lblUF
            // 
            this.lblUF.AutoSize = true;
            this.lblUF.Location = new System.Drawing.Point(668, 157);
            this.lblUF.Name = "lblUF";
            this.lblUF.Size = new System.Drawing.Size(21, 13);
            this.lblUF.TabIndex = 59;
            this.lblUF.Text = "UF";
            // 
            // txbBairro
            // 
            this.txbBairro.ForeColor = System.Drawing.Color.Gray;
            this.txbBairro.Location = new System.Drawing.Point(551, 154);
            this.txbBairro.Name = "txbBairro";
            this.txbBairro.Size = new System.Drawing.Size(100, 20);
            this.txbBairro.TabIndex = 58;
            this.txbBairro.Text = "Bairro";
            // 
            // txbNumero
            // 
            this.txbNumero.ForeColor = System.Drawing.Color.Gray;
            this.txbNumero.Location = new System.Drawing.Point(454, 154);
            this.txbNumero.Name = "txbNumero";
            this.txbNumero.Size = new System.Drawing.Size(71, 20);
            this.txbNumero.TabIndex = 57;
            this.txbNumero.Text = "Numero";
            // 
            // txbEndereco
            // 
            this.txbEndereco.ForeColor = System.Drawing.Color.Gray;
            this.txbEndereco.Location = new System.Drawing.Point(76, 154);
            this.txbEndereco.Name = "txbEndereco";
            this.txbEndereco.Size = new System.Drawing.Size(351, 20);
            this.txbEndereco.TabIndex = 56;
            this.txbEndereco.Text = "Rua";
            // 
            // lblEndereco
            // 
            this.lblEndereco.AutoSize = true;
            this.lblEndereco.Location = new System.Drawing.Point(22, 157);
            this.lblEndereco.Name = "lblEndereco";
            this.lblEndereco.Size = new System.Drawing.Size(53, 13);
            this.lblEndereco.TabIndex = 55;
            this.lblEndereco.Text = "Endereço";
            // 
            // txbGrauParentesco
            // 
            this.txbGrauParentesco.Location = new System.Drawing.Point(133, 242);
            this.txbGrauParentesco.Name = "txbGrauParentesco";
            this.txbGrauParentesco.Size = new System.Drawing.Size(269, 20);
            this.txbGrauParentesco.TabIndex = 62;
            // 
            // lblGrauParentesco
            // 
            this.lblGrauParentesco.AutoSize = true;
            this.lblGrauParentesco.Location = new System.Drawing.Point(29, 245);
            this.lblGrauParentesco.Name = "lblGrauParentesco";
            this.lblGrauParentesco.Size = new System.Drawing.Size(102, 13);
            this.lblGrauParentesco.TabIndex = 61;
            this.lblGrauParentesco.Text = "Grau de Parentesco";
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(174, 350);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(75, 23);
            this.btnCancelar.TabIndex = 63;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(292, 350);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(75, 23);
            this.btnLimpar.TabIndex = 64;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            // 
            // btnNovoParentesco
            // 
            this.btnNovoParentesco.Location = new System.Drawing.Point(12, 12);
            this.btnNovoParentesco.Name = "btnNovoParentesco";
            this.btnNovoParentesco.Size = new System.Drawing.Size(119, 23);
            this.btnNovoParentesco.TabIndex = 65;
            this.btnNovoParentesco.Text = "Novo Parentesco";
            this.btnNovoParentesco.UseVisualStyleBackColor = true;
            // 
            // btnProximo
            // 
            this.btnProximo.Location = new System.Drawing.Point(440, 350);
            this.btnProximo.Name = "btnProximo";
            this.btnProximo.Size = new System.Drawing.Size(75, 23);
            this.btnProximo.TabIndex = 66;
            this.btnProximo.Text = "Próximo";
            this.btnProximo.UseVisualStyleBackColor = true;
            // 
            // frmCadastroDependentes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(789, 394);
            this.Controls.Add(this.btnProximo);
            this.Controls.Add(this.btnNovoParentesco);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.txbGrauParentesco);
            this.Controls.Add(this.lblGrauParentesco);
            this.Controls.Add(this.txbUF);
            this.Controls.Add(this.lblUF);
            this.Controls.Add(this.txbBairro);
            this.Controls.Add(this.txbNumero);
            this.Controls.Add(this.txbEndereco);
            this.Controls.Add(this.lblEndereco);
            this.Controls.Add(this.txbNomeCompleto);
            this.Controls.Add(this.lblNomeCompleto);
            this.Controls.Add(this.txbCodigoDependentes);
            this.Controls.Add(this.lblCodigoDependentes);
            this.Name = "frmCadastroDependentes";
            this.Text = "Cadastro de Dependentes";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCodigoDependentes;
        private System.Windows.Forms.TextBox txbCodigoDependentes;
        private System.Windows.Forms.TextBox txbNomeCompleto;
        private System.Windows.Forms.Label lblNomeCompleto;
        private System.Windows.Forms.TextBox txbUF;
        private System.Windows.Forms.Label lblUF;
        private System.Windows.Forms.TextBox txbBairro;
        private System.Windows.Forms.TextBox txbNumero;
        private System.Windows.Forms.TextBox txbEndereco;
        private System.Windows.Forms.Label lblEndereco;
        private System.Windows.Forms.TextBox txbGrauParentesco;
        private System.Windows.Forms.Label lblGrauParentesco;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnNovoParentesco;
        private System.Windows.Forms.Button btnProximo;
    }
}